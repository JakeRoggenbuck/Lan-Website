import gpio_smart_system_lib as gssl

while(1):
    userInput = input('$ ')
